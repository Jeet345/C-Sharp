﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinqCRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showData();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            product.ProductName = nameTextbox.Text;
            product.ProductCategory = categoryTextbox.Text;
            product.Price = Int32.Parse(priceTextbox.Text);
            product.Qty = Int32.Parse(qtyTextbox.Text);

            LinqTestDataContext dc = new LinqTestDataContext();

            dc.Products.InsertOnSubmit(product);
            dc.SubmitChanges();

            showData();
        }

        public void showData()
        {
            LinqTestDataContext dc = new LinqTestDataContext();
            dataGridView1.DataSource = dc.Products;
        }
    }
}
